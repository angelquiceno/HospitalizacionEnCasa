from django.apps import AppConfig


class ApphospitalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appHospital'
