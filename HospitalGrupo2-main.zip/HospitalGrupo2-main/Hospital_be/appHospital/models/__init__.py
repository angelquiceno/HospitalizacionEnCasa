from .user import ClaseUser
from .Paciente import ClasePaciente
from .PersonalSalud import clasePersonalSalud
from .Familiar import ClaseFamiliar
from .SignosVitales import ClaseSignosVitales
from .HistoriaClinica import ClaseHistoriaClinica

